## vin_encode

### 概述

本工具是用于加密/解密 VIN 码的

### 使用

```
# 加密
./vin_encode encode L6T79P4N7RD091732

# 解密
./vin_encode decode dB4dgIsvjWgbZLw
```